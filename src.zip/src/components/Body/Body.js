import React from "react";
import Brands from "./Brands";
import SecondSlider from "./SecondSlider";
const Body = () => {
  return (
    <div>
      <Brands />
      <SecondSlider />
    </div>
  );
};
export default Body;
