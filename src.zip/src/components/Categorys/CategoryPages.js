import React from "react";
import TopWear from "./TopWear";
function CategoryPages() {
  return (
    <div>
      <TopWear />
    </div>
  );
}
export default CategoryPages;
