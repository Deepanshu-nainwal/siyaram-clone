import React from "react";
import { Link } from "react-router-dom";
import "./NewArrivals.css";
function NewArrivals() {
  return (
    <>
      <h1 className="h1">Oppss...!!!, Page not updated yet😒</h1>
      <Link className="ab" to="/">
        Home
      </Link>
    </>
  );
}
export default NewArrivals;
